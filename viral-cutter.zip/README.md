# Termux Viral Clip Cutter 🎬

Скрипт для Termux, который:
1. Скачивает YouTube-видео
2. Делит его на сцены
3. Выбирает 10 самых ярких моментов
4. Нарезает в вертикальном формате 9:16

## Установка и запуск

```bash
git clone https://github.com/ТВОЙ_АККАУНТ/viral-cutter.git
cd viral-cutter
bash setup_termux_env.sh
python termux_viral_clips.py
```

Клипы сохраняются в папке `clips/`.

Работает прямо с телефона через Termux.
